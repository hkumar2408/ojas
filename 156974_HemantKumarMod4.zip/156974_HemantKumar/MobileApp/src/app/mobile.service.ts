import { Injectable } from '@angular/core';
import { IMobile } from './IMobile';
import {Http,Response} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map"

@Injectable()
export class MobileService {
    mobiles: IMobile[];
    constructor(private http: Http) {
        
    }
    getAllMobiles():Observable< IMobile[]> {
            return this.http.get("app/mobile.json").
            map((response: Response) => <IMobile[]>response.json());
    }
}
