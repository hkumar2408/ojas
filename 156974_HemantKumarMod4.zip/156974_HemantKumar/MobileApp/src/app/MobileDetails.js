"use strict";
var MobileDetails = (function () {
    function MobileDetails(mobId, mobName, mobPrice) {
        this.mobId = mobId;
        this.mobName = mobName;
        this.mobPrice = mobPrice;
    }
    return MobileDetails;
}());
exports.MobileDetails = MobileDetails;
