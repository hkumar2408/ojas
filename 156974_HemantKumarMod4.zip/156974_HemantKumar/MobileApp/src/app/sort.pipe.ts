import { Pipe, PipeTransform } from '@angular/core';
import { IMobile } from "./IMobile";

@Pipe({
  name: 'sortingCompanies',
  pure: false
})
export class SortingCompaniesPipe implements PipeTransform {

  transform(mobile: IMobile[], path: string[], order: number): IMobile[] {

    // Check if is not null
    if (!mobile || !path || !order) return mobile;

    return mobile.sort((a: IMobile, b: IMobile) => {
      path.forEach(property => {  // We go for each property followed by path
        a = a[property];
        b = b[property];
      })

      return a > b ? order : order * (- 1); //Order is changed here
    })
  }

}