"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var mobile_service_1 = require("./mobile.service");
var MobileList = (function () {
    function MobileList(mobileService) {
        this.mobileService = mobileService;
        this.path = ['Mobile'];
        this.order = 1;
        this.search = '';
        this.index = 0;
    }
    /**********************************************************************
    - Function Name    :   ngOnInit()
    - Return Type      :   void
    - Author           :   Hemant Kumar
    - Creation Date    :   12/10/2018
    - Description      :   Calling getAllMobiles() method to fetch details from the JSON file
    ***********************************************************************/
    MobileList.prototype.ngOnInit = function () {
        var _this = this;
        console.log("ng-init called...");
        this.mobileService.getAllMobiles().subscribe(function (mobileData) { return _this.mobiles = mobileData; });
    };
    /**********************************************************************
    - Function Name    :   deleteMobile()
    - Input Parameters :   mobId: number
    - Return Type      :   void
    - Author           :   Hemant Kumar
    - Creation Date    :   12/10/2018
    - Description      :   Deletion of data based on Mobile Id
    ***********************************************************************/
    MobileList.prototype.deleteMobile = function (mobId) {
        for (var i = 0; i < this.mobiles.length; i++) {
            if (this.mobiles[i].mobId == mobId) {
                this.mobiles.splice(i, 1);
                return;
            }
        }
    };
    /**********************************************************************
    - Function Name    :   sortTable()
    - Return Type      :   NA
    - Author           :   Hemant Kumar
    - Creation Date    :   12/10/2018
    - Description      :  It is used to sort the entries
    ***********************************************************************/
    MobileList.prototype.sortTable = function (prop) {
        this.path = prop.split('.');
        this.order = this.order * 1; // change order
        return false; // do not reload
    };
    return MobileList;
}());
MobileList = __decorate([
    core_1.Component({
        selector: '<my-component></my-component>',
        templateUrl: './app.mobilecomponent.html',
        providers: [mobile_service_1.MobileService]
    }),
    __metadata("design:paramtypes", [mobile_service_1.MobileService])
], MobileList);
exports.MobileList = MobileList;
