import { Component, OnInit } from '@angular/core';
import { IMobile } from './IMobile';
import { MobileDetails } from './MobileDetails';
import { MobileService } from './mobile.service';

@Component({
    selector: '<my-component></my-component>',
    templateUrl: './app.mobilecomponent.html',
    providers: [MobileService]
})

export class MobileList implements OnInit {
    
    path: string[] = ['Mobile'];
    order: number = 1;

    search: string = '';
    index: number = 0;
    
    mobiles: IMobile[];

    constructor(private mobileService: MobileService) {}
    
    
    
    /**********************************************************************
    - Function Name    :   ngOnInit()
    - Return Type      :   void
    - Author           :   Hemant Kumar
    - Creation Date    :   12/10/2018
    - Description      :   Calling getAllMobiles() method to fetch details from the JSON file                    
    ***********************************************************************/
    
    ngOnInit(): void {
        console.log("ng-init called...");
        this.mobileService.getAllMobiles().subscribe((mobileData) => this.mobiles = mobileData);
    }
    

    
    
    /**********************************************************************
    - Function Name    :   deleteMobile()
    - Input Parameters :   mobId: number
    - Return Type      :   void
    - Author           :   Hemant Kumar
    - Creation Date    :   12/10/2018
    - Description      :   Deletion of data based on Mobile Id
    ***********************************************************************/

    deleteMobile(mobId: number):void {
        for(var i = 0; i < this.mobiles.length; i++) 
        {
            if(this.mobiles[i].mobId == mobId)
            {
                this.mobiles.splice(i, 1);
                return;
            }
        }
        }
  
    
    
    
    /**********************************************************************
    - Function Name    :   sortTable()
    - Return Type      :   NA
    - Author           :   Hemant Kumar
    - Creation Date    :   12/10/2018
    - Description      :  It is used to sort the entries
    ***********************************************************************/
    
    sortTable( prop: string ) {
        this.path = prop.split( '.' )
        this.order = this.order * 1 ; // change order
        return false; // do not reload
    }
}