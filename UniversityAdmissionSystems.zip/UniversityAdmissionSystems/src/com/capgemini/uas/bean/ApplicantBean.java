package com.capgemini.uas.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name = "Application")
public class ApplicantBean {
	
	@Id
	@SequenceGenerator(name = "appseq", sequenceName = "applicationId_seq")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "appseq")
	@Column(name="application_id")
	private int appId;
	
	@Column(name="full_name")
	private String appName;
	
	@Column(name="date_of_birth")
	private Date appDOB;
	
	@Column(name="highest_qualification")
	private String qualification;
	
	@Column(name="marks_obtained")
	private int marks;
	
	@Column(name="goals")
	@NotEmpty(message="goals is required")
	private String goals;
	
	@Column(name="email_id")
	private String emailId;
	
	@Column(name="Scheduled_program_id")
	private String scheduleProgId;
	
	@Column(name="status")
	private String status;
	
	@Column(name="Date_Of_Interview")
	private Date appDOI;

	public ApplicantBean() {
		//Default Constructor
	}
		
	//Getters and Setters Methods
	
	public int getAppId() {
		return appId;
	}
	public void setAppId(int appId) {
		this.appId = appId;
	}
	
	
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	
	
	public Date getAppDOB() {
		return appDOB;
	}
	public void setAppDOB(Date appDOB) {
		this.appDOB = appDOB;
	}
	
	
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	
	
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	
	
	public String getGoals() {
		return goals;
	}
	public void setGoals(String goals) {
		this.goals = goals;
	}
	
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	
	public String getScheduleProgId() {
		return scheduleProgId;
	}
	public void setScheduleProgId(String scheduleProgId) {
		this.scheduleProgId = scheduleProgId;
	}
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	public Date getAppDOI() {
		return appDOI;
	}
	public void setAppDOI(Date appDOI) {
		this.appDOI = appDOI;
	}
	
	//toString() Method Overriden
	@Override
	public String toString() {
		return "Applicant \nId = " + appId + "\nName = " + appName
				+ "\nDOB = " + appDOB + "\nQualification = " + qualification
				+ "\nMarks = " + marks + "\nGoals = " + goals + "\nEmail-Id = "
				+ emailId + "\nScheduled Program Id = " + scheduleProgId + "\n Application status = "
				+ status + "\nAppDOI = " + appDOI + "]";
	}
}