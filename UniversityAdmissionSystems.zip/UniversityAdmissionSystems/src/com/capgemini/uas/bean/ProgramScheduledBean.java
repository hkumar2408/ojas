package com.capgemini.uas.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;



@Entity
@Table(name = "Programs_Scheduled")
public class ProgramScheduledBean {
	
	//Variable Declaration
	@Id
	@Column(name="Scheduled_program_id")
	@Size(max=5,message="Maximum size is 5 characters")
	@NotEmpty(message="Enter the scheduled id")
	private String scheduleProgId; 
	
	@Size(max=5,message="Maximum size is 5 characters")
	@NotEmpty(message="Enter the name")
	@Column(name="Programname")
	private String progName;
	
	@Column(name="Location")
	private String location;
	
	@Column(name="start_date")
	private Date start;
	
	@Column(name="end_date")
	private Date end;
	
	@Column(name="session_per_week")
	private int session;
	
	//Getters and Setters Method	
	public String getScheduleProgId() {
		return scheduleProgId;
	}
	public void setScheduleProgId(String scheduleProgId) {
		this.scheduleProgId = scheduleProgId;
	}
	public String getProgName() {
		return progName;
	}
	public void setProgName(String progName) {
		this.progName = progName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Date getStart() {
		return start;
	}
	public void setStart(Date start) {
		this.start = start;
	}
	public Date getEnd() {
		return end;
	}
	public void setEnd(Date end) {
		this.end = end;
	}
	public int getSession() {
		return session;
	}
	public void setSession(int session) {
		this.session = session;
	}
	
	//toString() Method Overriden
	@Override
	public String toString() {
		return "Program Scheduled\nScheduled Progam Id = " + scheduleProgId
				+ "\n Program Name = " + progName + "\nLocation = " + location
				+ "\nStart Date = " + start + "\nEnd Date = " + end + "\nSession = "
				+ session + "]";
	}

	// Parameterized Constructor
	public ProgramScheduledBean(String scheduleProgId, String progName,
			String location, Date start, Date end, int session) {

		this.scheduleProgId = scheduleProgId;
		this.progName = progName;
		this.location = location;
		this.start = start;
		this.end = end;
		this.session = session;
	}
	
	//Default Constructor
	public ProgramScheduledBean() {
	}
}