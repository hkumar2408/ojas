package com.capgemini.uas.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.uas.bean.ApplicantBean;
import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.exception.UASException;
import com.capgemini.uas.service.IApplicantService;



@Controller
public class ApplicantController {
	private static final Logger LOGGER = Logger.getRootLogger();
	@Autowired
	private IApplicantService applicantService;
	
	@RequestMapping("/applicant")
	public String showApplicantHome() {
		LOGGER.info("In Applicant home");
		return "jsp/applicantHome";
	}
	
	@RequestMapping("/applicantview")
	public String showApplicantView(Model model) throws UASException {
		List<ProgramScheduledBean> progList = applicantService.getAllPrograms();
		model.addAttribute("progList", progList);
		return "jsp/applicantView";
	}

	@RequestMapping("/applicantApply")
	public String applicantApply(@RequestParam("pid")String scheduleProgId ,Model model) {
		LOGGER.info("Apply applicant is being called");
	model.addAttribute("scheduleProgId", scheduleProgId);
	model.addAttribute("ApplicantBean", new ApplicantBean());
	return "jsp/applicantForm";
	}
	
	
	@RequestMapping("/submitapplication")
	public String submitApplication(@ModelAttribute("ApplicantBean")@Valid ApplicantBean applicant, 
			BindingResult bindingResult, Model model) throws UASException {
		LOGGER.info("Application form is being submitted");
		boolean success = false;
		success =  applicantService.saveApplication(applicant);
		
		if(success) {
			model.addAttribute("applicant", applicant);
			return "jsp/applicantConfirmation";
			}
		else {
			return "jsp/dataerror";
			}
	}
	
	@RequestMapping("/statuscheckform")
	public String checkStatus(Model model) throws UASException {
		LOGGER.info("Status of application is being checked");
		model.addAttribute("ApplicantBean", new ApplicantBean());
		return "jsp/applicantcheck";
	}
	
	@RequestMapping("/showstatus")
	public String showStatus(@ModelAttribute("ApplicantBean")@Valid ApplicantBean applicant, 
			BindingResult bindingResult, Model model) throws UASException {
     	ApplicantBean applicantRetrieved =  applicantService.getApplicationById(applicant.getAppId());
		model.addAttribute("applicantRetrieved", applicantRetrieved);
		return "jsp/applicantstatus";
	}
	
	@ExceptionHandler(Exception.class)
	public ModelAndView handleError(Exception exception) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("err", exception);
		mav.setViewName("jsp/dataerror");
		return mav;
	}

}