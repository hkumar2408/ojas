package com.capgemini.uas.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.uas.bean.ApplicantBean;
import com.capgemini.uas.bean.ParticipantBean;
import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.bean.UsersBean;
import com.capgemini.uas.service.IMacService;

@Controller
public class MacController {

	@Autowired
	private IMacService macService;

	ParticipantBean participant = null;
	private static final Logger LOGGER = Logger.getRootLogger();
	
	@RequestMapping("/macLogin")
	public String macLogin(Model model) {
		model.addAttribute("userObj", new UsersBean());
		return "jsp/login";
	}


	@RequestMapping("/displayPrograms")
	public String displayPrograms(Model model) {
	
		List<ProgramScheduledBean> programList = macService.getProgramList();
		LOGGER.info("Program List displayed");
		model.addAttribute("plist", programList);
		return "jsp/programDetails";
	}

	@RequestMapping("/macHome")
	public String macHome(Model model) {
		return "/jsp/macView";

	}
	
	@RequestMapping("/submitProgram")
	public String submitProgram(@RequestParam("pid") String id,@RequestParam("pname") String name, Model model) {

		List<ApplicantBean> appList = macService.getApplicantList(id);
		LOGGER.info("Program selected");
		model.addAttribute("alist", appList);
		return "jsp/applicantDetails";

	}

	@RequestMapping("/displayProgramList")
	public String displayProgramList(Model model) {
		
		List<ProgramScheduledBean> programList = macService.getProgramList();
		LOGGER.info("Displaying all program list");
		model.addAttribute("plist", programList);
		return "jsp/programList";
	}

	@RequestMapping("/submitProgramName")
	public String submitProgramName(@RequestParam("pid") String id,@RequestParam("pname") String name, Model model) {

		List<ApplicantBean> appList = macService.getAppliedApplicant(id);
		LOGGER.info("Submitting Program Name");
		model.addAttribute("alist", appList);
		return "jsp/applicantList";

	}

	@RequestMapping("/acceptApplicant")
	public String acceptApplicant(@RequestParam("aid") int id, Model model) {

		ApplicantBean applicant = macService.fetchApplicant(id);
		LOGGER.info("Applicant Accepted");
		model.addAttribute("aid", id);
		model.addAttribute("applicant", applicant);

		return "jsp/scheduleInterview";

	}

	@RequestMapping("/rejectApplicants")
	public String rejectApplicants(@RequestParam("aid") int appId, Model model) {
		boolean isRejected = macService.rejectApplicant(appId);
		LOGGER.info("Applicant Rejected");
		if (isRejected) {
			model.addAttribute("aid",appId);
			return "jsp/rejectApplicant";
		} else {
			LOGGER.error("Error with reject applicant");
			return "jsp/notUpdated";
		}
	}
	@RequestMapping("/dateSet")
	public String updateInterview(@ModelAttribute("applicant")ApplicantBean applicants,BindingResult binding,Model model){
		boolean success = macService.updateInterviewDate(applicants);
		LOGGER.info("Updated Interview date");
		if(success){
			model.addAttribute("applicant", applicants);
			return "jsp/acceptApplicant";
		}
		else{
			LOGGER.error("Interview date not updated");
		return "jsp/notUpdated";
		}
		
	}

	

	@RequestMapping("/updateAfterInterview")
	public String updateAfterInterview(Model model) {
		List<ApplicantBean> applicantList = macService.getAcceptedApplicant();
		LOGGER.info("Getting Accepted Applicants");
		model.addAttribute("acceptedList", applicantList);
		return "jsp/afterinterview";
	}

	@RequestMapping("/confirmApplicant")
	public String confirmApplicant(@RequestParam("appId") int appId,@RequestParam("email") String emailId,
			@RequestParam("programId") String scheduleProgId, Model model) {
		boolean isConfirm = macService.confirmApplicant(appId);
		LOGGER.info("Applicant Confirmed");
		
		if (isConfirm) {
			model.addAttribute("appId", appId);
				return "jsp/confirmApplicant";
			
		} else {
			return "jsp/notUpdated";
		}
	}


	@ExceptionHandler(Exception.class)
	public ModelAndView handleError(Exception exception) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("err", exception);
		mav.setViewName("jsp/dataerror");
		return mav;
	}
}
