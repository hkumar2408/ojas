package com.capgemini.uas.controller;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.uas.bean.UsersBean;
import com.capgemini.uas.exception.UASException;
import com.capgemini.uas.service.IMainService;

@Controller
public class MainController {
	
	@Autowired
	private IMainService mainService;
	
	Logger logger=Logger.getLogger(MainController.class);
	

	@RequestMapping(value="/mainhome")
	public String getHome(){
		return "index";	
	}
	
	@RequestMapping(value="/aboutus")
	public String getAboutUs(){
		return "jsp/aboutus";	
	}
	
	@RequestMapping("/mainLogin")
	public String mainLogin(Model model) {
		model.addAttribute("userObj", new UsersBean());
		return "jsp/login";

	}

	@RequestMapping("/validateLogin")
	public String validateLogin(@ModelAttribute("userObj") @Valid UsersBean user,BindingResult result, Model model) {
		if (result.hasErrors()) {
			return "jsp/login";
		}
		try {
			UsersBean userInfo = mainService.isValidUserLogin(user);
			if (userInfo != null) {
				if (userInfo.getRole().equalsIgnoreCase("MAC")) {
					logger.info("In mac");
					return "jsp/macView";
				} else if (userInfo.getRole().equalsIgnoreCase("admin")) {
					return "jsp/adminHome";
				}
			} else {
				return "jsp/login";
			}
		} catch (UASException exception) {
			logger.info("error occured");
			String errObj = exception.getMessage();
			model.addAttribute("errObj", errObj);
			return "jsp/invalidCredential";
		}
		return "jsp/login";
	}
	
	@ExceptionHandler(Exception.class)
	public ModelAndView handleError(Exception e) {
		// send email to control center
		ModelAndView mav = new ModelAndView();
		mav.addObject("err", e);
		mav.setViewName("dataerror");
		System.out.println(e.getMessage());
		return mav;
	}
}
