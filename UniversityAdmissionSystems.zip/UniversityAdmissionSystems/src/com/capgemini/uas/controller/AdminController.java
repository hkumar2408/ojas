package com.capgemini.uas.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.uas.bean.ApplicantBean;
import com.capgemini.uas.bean.ProgramOfferedBean;
import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.exception.UASException;
import com.capgemini.uas.service.IAdminService;

@Controller
public class AdminController {
	
	@Autowired
	IAdminService adminService;
	
	private static final Logger LOGGER=Logger.getLogger(AdminController.class);
	
	@RequestMapping(value="/administrator")
	public String goHome(Model model) {
		
		return "jsp/adminHome";
	}
	@RequestMapping(value="/programOffered")
	public String programOffered(Model model){
		LOGGER.info("Showing Programs Offered...");
		model.addAttribute("choice", 0);
		List<ProgramOfferedBean> progList;
		progList = adminService.getAllProgramOffered();
		model.addAttribute("progList", progList);
		return "jsp/universityProgramOffer";	
	}
	@RequestMapping("/addProgOffered")
	public String addProgram(Model model) {
		model.addAttribute("progOffered", new ProgramOfferedBean());
		return "jsp/addProgramOffered";
	}
	@RequestMapping("/newProgOffered")
	public String addProgramOffered(@ModelAttribute("progOffered") ProgramOfferedBean program,
			BindingResult bindingResult, Model model) {
		model.addAttribute("choice", 1);
		String progName = adminService.addProgOffered(program);
		program.setProgName(progName);
		
		List<ProgramOfferedBean> progList = adminService.getAllProgramOffered();
		model.addAttribute("progList", progList);
		return "jsp/universityProgramOffer";
	}
	@RequestMapping("/updateProgOffered")
	public String getCourse(@RequestParam("proName") String name, Model model) {
		model.addAttribute("choice", 2);
		ProgramOfferedBean program = adminService.getProgOffered(name);
		model.addAttribute("program", program);
		
		List<ProgramOfferedBean> progList = adminService.getAllProgramOffered();
		model.addAttribute("progList", progList);
		return "jsp/universityProgramOffer";
	}
	@RequestMapping("/updatingProgOffered")
	public String updateCourse(@ModelAttribute("program") ProgramOfferedBean program,
			BindingResult bindingResult, Model model) {
		model.addAttribute("choice", 0);
		adminService.updateProgOffered(program);
		
		List<ProgramOfferedBean> progList = adminService.getAllProgramOffered();
		model.addAttribute("progList", progList);
		
		return "jsp/universityProgramOffer";
	}
	@RequestMapping("/deleteProgOffered")
	public String deleteProgOffered(@RequestParam("proName") String name, Model model) {
		LOGGER.info("Deleting Program Offered...");
		adminService.deleteProgOffered(name);
		model.addAttribute("choice", 0);
		
		List<ProgramOfferedBean> progList;
		progList = adminService.getAllProgramOffered();
		model.addAttribute("progList", progList);
		return "jsp/universityProgramOffer";
	}
	
	@RequestMapping(value="/programSchedule")
	public String programScheduled(Model model){
		LOGGER.info("Showing Programs Scheduled...");
		List<ProgramScheduledBean> progSchList = adminService.getAllProgramScheduled();
		model.addAttribute("progScheduleList", progSchList);
		return "jsp/universitySchedule";
	}
	@RequestMapping("/addProgScheduled")
	public String addProgramScheduled(Model model) {
		List<String> progNameList = adminService.getProgramNameList();		
		model.addAttribute("progScheduled", new ProgramScheduledBean());
		model.addAttribute("progNameList", progNameList);
		return "jsp/addProgramScheduled";
	}
	@RequestMapping("/newProgScheduled")
	public String addProgramScheduled(@Valid @ModelAttribute("progScheduled") ProgramScheduledBean program,
			BindingResult bindingResult, Model model) {
		String progId = adminService.addProgScheduled(program);
		program.setScheduleProgId(progId);
		
		List<ProgramScheduledBean> progSchList = adminService.getAllProgramScheduled();
		model.addAttribute("progScheduleList", progSchList);
		return "jsp/universitySchedule";
	}
	@RequestMapping("/deleteProgScheduled")
	public String deleteProgScheduled(@RequestParam("proId") String progId, Model model) {
		LOGGER.info("Deleting Program Scheduled...");
		adminService.deleteProgScheduled(progId);
		
		List<ProgramScheduledBean> progSchList = adminService.getAllProgramScheduled();
		model.addAttribute("progScheduleList", progSchList);
		return "jsp/universitySchedule";
	}
	
	@RequestMapping("/viewReports")
	public String showViewReports(Model model) {
		LOGGER.info("show view reports page");
		model.addAttribute("programScheduledBean", new ProgramScheduledBean());
		model.addAttribute("programScheduled", new ProgramScheduledBean());
		List<String> progIdList = adminService.getProgramIdList();
		model.addAttribute("progIdList", progIdList);
		return "jsp/adminViewReports";
	}	
	@RequestMapping("/viewApplicantReport")
	public String showApplicantReport(@ModelAttribute("programScheduledBean")ProgramScheduledBean programScheduledBean, 
			BindingResult bindingResult, Model model) throws UASException {
		LOGGER.info("Applicant report");
		List<ApplicantBean> applicantApplied =  adminService.getAllApplicantsApplied(programScheduledBean.getScheduleProgId());
		List<ApplicantBean> applicantAccepted =  adminService.getAllApplicantsAccepted(programScheduledBean.getScheduleProgId());
		List<ApplicantBean> applicantRejected =  adminService.getAllApplicantsRejected(programScheduledBean.getScheduleProgId());
		List<ApplicantBean> applicantConfirmed =  adminService.getAllApplicantsConfirmed(programScheduledBean.getScheduleProgId());
		model.addAttribute("scheduleProgId", programScheduledBean.getScheduleProgId());
		model.addAttribute("applicantApplied", applicantApplied);
		model.addAttribute("applicantAccepted", applicantAccepted);
		model.addAttribute("applicantRejected", applicantRejected);
		model.addAttribute("applicantConfirmed", applicantConfirmed);
		return "jsp/adminViewApplicantReport";
	}
	@RequestMapping(value="/datedProgramSchedule")
	public String datedProgramScheduled(@ModelAttribute("programScheduled")ProgramScheduledBean programScheduledBean, 
			BindingResult bindingResult, Model model){
		LOGGER.info("Schedule program  report");
		
		List<ProgramScheduledBean> progSchList = adminService.getDatedProgramScheduled(programScheduledBean.getStart(),programScheduledBean.getEnd());
		model.addAttribute("progScheduleList", progSchList);
		return "jsp/universitySchedule";
	}
	
	
	@ExceptionHandler(Exception.class)
	public ModelAndView handleError(Exception exception) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("err", exception);
		mav.setViewName("jsp/constraintError");
		System.out.println(exception.getMessage());
		return mav;
	}
}
