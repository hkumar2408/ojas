package com.capgemini.uas.dao;

import java.util.List;

import com.capgemini.uas.bean.ApplicantBean;
import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.bean.UsersBean;
import com.capgemini.uas.exception.UASException;


public interface IMacDao {

	UsersBean isValidUserLogin(UsersBean user) throws UASException;

	List<ApplicantBean> getAcceptedApplicant();

	boolean confirmApplicant(int appId);

	boolean rejectApplicant(int appId);

	boolean addParticipant(int appId, String emailId, String scheduleProgId);

	List<ProgramScheduledBean> getProgramList();

	List<ApplicantBean> getApplicantList(String id);

	List<ApplicantBean> getAppliedApplicant(String id);

	ApplicantBean fetchApplicant(int id);

	boolean updateInterviewDate(ApplicantBean applicant);


}
