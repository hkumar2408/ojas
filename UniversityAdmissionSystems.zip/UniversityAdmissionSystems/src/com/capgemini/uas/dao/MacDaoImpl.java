package com.capgemini.uas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.uas.bean.ApplicantBean;
import com.capgemini.uas.bean.ParticipantBean;
import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.bean.UsersBean;
import com.capgemini.uas.exception.UASException;

@Repository
@Transactional
public class MacDaoImpl implements IMacDao {
	@PersistenceContext
	EntityManager entityManager;
	ApplicantBean applicant = null;
	private static final Logger LOGGER= Logger.getLogger(MacDaoImpl.class);

	@Override
	public UsersBean isValidUserLogin(UsersBean userDetails)throws UASException {
		UsersBean user;
		try {
			user = entityManager.find(UsersBean.class, userDetails.getLoginId());
		} catch (Exception exception) {
			LOGGER.info(exception.getMessage());
			throw new UASException(exception.getMessage());
		} finally {
			if (entityManager != null) {
				LOGGER.info("entity manager is closed");
				entityManager.close();
			}
		}
		if (user != null && userDetails.getPassword().equals(user.getPassword()))
			return user;
		else {
			LOGGER.info("Username or password does not match");
			throw new UASException("Username or password does not match");
		}
	}

	@Override
	public List<ApplicantBean> getAcceptedApplicant() {

		String qry = "SELECT applicant FROM ApplicantBean applicant where applicant.status='ACCEPTED'";
		TypedQuery<ApplicantBean> query = entityManager.createQuery(qry,
				ApplicantBean.class);
		List<ApplicantBean> aList = query.getResultList();
		return aList;
	}

	@Override
	public boolean confirmApplicant(int applicantId) {
		boolean confirmDone = false;
		int isConfirm = 0;
		String updateQuery = "UPDATE ApplicantBean applicant SET applicant.status='CONFIRMED' where applicant.appId=:applicantId";
		Query query = entityManager.createQuery(updateQuery);
		query.setParameter("applicantId", applicantId);
		isConfirm = query.executeUpdate();
		if (isConfirm > 0) {
			confirmDone = true;
			return confirmDone;
		} else {
			return confirmDone;
		}
	}

	@Override
	public boolean rejectApplicant(int applicantId) {
		boolean rejectDone = false;
		int isRejected = 0;
		String updateQuery = "UPDATE ApplicantBean applicant SET applicant.status='REJECTED' where applicant.appId=:applicantId";
		Query query = entityManager.createQuery(updateQuery);
		query.setParameter("applicantId", applicantId);
		isRejected = query.executeUpdate();
		if (isRejected > 0) {
			rejectDone = true;
			return rejectDone;
		} else {
			return rejectDone;
		}
	}

	@Override
	public boolean addParticipant(int appId, String emailId,String scheduleProgId) {
		boolean success=false;
		ParticipantBean participant=new ParticipantBean();
		
		participant.setAppId(appId);
		participant.setEmailId(emailId);
		participant.setScheduleProgId(scheduleProgId);
		System.out.println("in persist");
         entityManager.persist(participant);
         success=true;
		return success;
	}
	@Override
	public List<ProgramScheduledBean> getProgramList() {
		String qry = "SELECT program FROM ProgramScheduledBean program";
		TypedQuery<ProgramScheduledBean> query = entityManager.createQuery(qry, ProgramScheduledBean.class);
		List<ProgramScheduledBean> programList = query.getResultList();
		return programList;
	}

	@Override
	public List<ApplicantBean> getApplicantList(String id) {
		System.out.println(id);
		String qry = "SELECT applicant FROM ApplicantBean applicant where applicant.scheduleProgId = :id ";
		TypedQuery<ApplicantBean> query = entityManager.createQuery(qry, ApplicantBean.class);
		query.setParameter("id", id);
		List<ApplicantBean> appList = query.getResultList();
		return appList;
	}

	@Override
	public List<ApplicantBean> getAppliedApplicant(String id) {
		System.out.println(id);
		String qry = "SELECT applicant FROM ApplicantBean applicant where applicant.status='APPLIED' and applicant.scheduleProgId = :id ";
		TypedQuery<ApplicantBean> query = entityManager.createQuery(qry, ApplicantBean.class);
		query.setParameter("id", id);
		List<ApplicantBean> appList = query.getResultList();
		return appList;
	}

	@Override
	public ApplicantBean fetchApplicant(int id) {
		String qStr = "SELECT applicant FROM ApplicantBean applicant WHERE applicant.appId = :id";
		TypedQuery<ApplicantBean> query = entityManager.createQuery(qStr, ApplicantBean.class);
		query.setParameter("id", id);
		ApplicantBean applicant = query.getSingleResult();
		return applicant;
	}

	@Override
	public boolean updateInterviewDate(ApplicantBean applicant) {
		
		entityManager.merge(applicant);
		if(applicant.getAppDOI()!= null)
		return true;
		else
		return false;
	}

	
}


