package com.capgemini.uas.dao;

import java.sql.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.uas.bean.ApplicantBean;
import com.capgemini.uas.bean.ProgramOfferedBean;
import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.exception.UASException;

@Repository
@Transactional
public class AdminDaoImpl implements IAdminDao {

	@PersistenceContext
	private EntityManager eManager;
	
	private static final Logger LOGGER= Logger.getLogger(AdminDaoImpl.class);
	
	@Override
	public List<ProgramOfferedBean> getAllProgramOffered() {
		String queryStr = "SELECT progBean FROM ProgramOfferedBean progBean";
		TypedQuery<ProgramOfferedBean> query = eManager.createQuery(queryStr, ProgramOfferedBean.class);
		List<ProgramOfferedBean> progList = query.getResultList();
		return progList;
	}

	@Override
	public List<ProgramScheduledBean> getAllProgramScheduled(){
		String queryStr = "SELECT progSchedule FROM ProgramScheduledBean progSchedule";
		TypedQuery<ProgramScheduledBean> query = eManager.createQuery(queryStr, ProgramScheduledBean.class);
		List<ProgramScheduledBean> proSchList = query.getResultList();
		return proSchList;
	}

	@Override
	public ProgramOfferedBean deleteProgOffered(String name) {
		ProgramOfferedBean proBean = eManager.find(ProgramOfferedBean.class, name);;
		eManager.remove(proBean);
		
		return proBean;
	}

	@Override
	public String addProgOffered(ProgramOfferedBean program) {
		eManager.persist(program);
		return program.getProgName();
	}

	@Override
	public ProgramOfferedBean getProgOffered(String name) {
		ProgramOfferedBean program = eManager.find(ProgramOfferedBean.class, name);
		return program;
	}

	@Override
	public void updateProgOffered(ProgramOfferedBean program) {
		
		eManager.merge(program);
	}

	@Override
	public String addProgScheduled(ProgramScheduledBean program) {
		eManager.persist(program);
		return program.getScheduleProgId();
	}

	@Override
	public void deleteProgScheduled(String progId) {
		ProgramScheduledBean proSchedule = eManager.find(ProgramScheduledBean.class, progId);;
		eManager.remove(proSchedule);
		
	}

	@Override
	public List<ProgramScheduledBean> getDatedProgramScheduled(Date fromDate,
			Date toDate) {
		String queryStr = "SELECT progSchedule FROM ProgramScheduledBean progSchedule WHERE"
				+ " progSchedule.start BETWEEN :fromDate and :toDate";
		TypedQuery<ProgramScheduledBean> query = eManager.createQuery(queryStr, ProgramScheduledBean.class);
		query.setParameter("fromDate", fromDate);
		query.setParameter("toDate", toDate);
		List<ProgramScheduledBean> proSchList = query.getResultList();
		return proSchList;
	}
	
	@Override
	public List<ApplicantBean> getAllApplicantsApplied(String scheduleProgId) throws UASException {
		LOGGER.info("Dao impl to get All Applicants Applied");
		String selectAllAppliedQuery = "SELECT applicant FROM ApplicantBean applicant WHERE applicant.status='APPLIED' AND applicant.scheduleProgId=:progid";
		TypedQuery<ApplicantBean> query = eManager.createQuery(selectAllAppliedQuery, ApplicantBean.class);
		query.setParameter("progid",scheduleProgId);
		List<ApplicantBean> AppliedList = query.getResultList();
		LOGGER.info("Fetching from DB (DAO)....");
		
		return AppliedList;
	}

	@Override
	public List<ApplicantBean> getAllApplicantsAccepted(String scheduleProgId) throws UASException {
		LOGGER.info("Dao impl to get All Applicants Accepted");
		String selectAllAcceptedQuery = "SELECT applicant FROM ApplicantBean applicant WHERE applicant.status='ACCEPTED' AND applicant.scheduleProgId=:progid";
		TypedQuery<ApplicantBean> query = eManager.createQuery(selectAllAcceptedQuery, ApplicantBean.class);
		query.setParameter("progid",scheduleProgId);
		List<ApplicantBean> AcceptedList = query.getResultList();
		LOGGER.info("Fetching from DB (DAO)....");
		
		return AcceptedList;
	}

	@Override
	public List<ApplicantBean> getAllApplicantsRejected(String scheduleProgId) throws UASException {
		LOGGER.info("Dao impl to get All Applicants Rejected");
		String selectAllRejectedQuery = "SELECT applicant FROM ApplicantBean applicant WHERE applicant.status='REJECTED' AND applicant.scheduleProgId=:progid";
		TypedQuery<ApplicantBean> query = eManager.createQuery(selectAllRejectedQuery, ApplicantBean.class);
		query.setParameter("progid",scheduleProgId);
		List<ApplicantBean> RejectedList = query.getResultList();
		LOGGER.info("Fetching from DB (DAO)....");
		
		return RejectedList;
	}

	@Override
	public List<ApplicantBean> getAllApplicantsConfirmed(String scheduleProgId) throws UASException {
		LOGGER.info("Dao impl to get All Applicants ConfirmedList");
		String selectAllRejectedQuery = "SELECT applicant FROM ApplicantBean applicant WHERE applicant.status='CONFIRMED' AND applicant.scheduleProgId=:progid";
		TypedQuery<ApplicantBean> query = eManager.createQuery(selectAllRejectedQuery, ApplicantBean.class);
		query.setParameter("progid",scheduleProgId);
		List<ApplicantBean> ConfirmedList = query.getResultList();
		LOGGER.info("Fetching from DB (DAO)....");
		
		return ConfirmedList;
	}
	@Override
	public List<String> getProgramNameList() {

		String queryStr = "SELECT progBean.progName FROM ProgramOfferedBean progBean";
		TypedQuery<String> query = eManager.createQuery(queryStr, String.class);
		List<String> proNameList = query.getResultList();
		
		return proNameList;
	}

	@Override
	public List<String> getProgramIdList() {
		String queryStr = "SELECT progBean.scheduleProgId FROM ProgramScheduledBean progBean";
		TypedQuery<String> query = eManager.createQuery(queryStr, String.class);
		List<String> proIdList = query.getResultList();
		
		return proIdList;
	}

}
