package com.capgemini.uas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.capgemini.uas.bean.ApplicantBean;
import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.exception.UASException;


@Transactional
@Repository
public class ApplicantDaoImpl implements IApplicantDao {
	
	@PersistenceContext
	private EntityManager eManager;

	private static final Logger LOGGER= Logger.getLogger(ApplicantDaoImpl.class);
	
	@Override
	public List<ProgramScheduledBean> getAllPrograms() throws UASException {
		LOGGER.info("Dao impl to get all programs");
		String selectAllQuery = "SELECT programs FROM ProgramScheduledBean programs";
		TypedQuery<ProgramScheduledBean> query = eManager.createQuery(selectAllQuery, ProgramScheduledBean.class);
		List<ProgramScheduledBean> programList = query.getResultList();
		LOGGER.info("Fetching program objects from DB (DAO)....");
		return programList;
	}
	
	@Override
	public boolean saveApplication(ApplicantBean applicant) throws UASException{
		boolean success = false;
		LOGGER.info("Entered Dao for saving applicant");
		try {
			eManager.persist(applicant);
			success = true;
		} catch (Exception e) {
			// log error
			e.printStackTrace(); // remove this
		}
		return success;
	}
	

	@Override
	public ApplicantBean getApplicationById(int appId) throws UASException{
		LOGGER.info("Dao impl to get application by id");
		ApplicantBean applicant = eManager.find(ApplicantBean.class, appId);
		return applicant;
	}
}
