package com.capgemini.uas.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.uas.bean.UsersBean;
import com.capgemini.uas.exception.UASException;

@Repository
@Transactional
public class MainDaoImpl implements IMainDao {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public UsersBean isValidUserLogin(UsersBean userDetails) throws UASException {
		UsersBean user;
		try {
			user = entityManager.find(UsersBean.class,
					userDetails.getLoginId());
		} catch (Exception exception) {
			//logger.info(e.getMessage());
			throw new UASException(exception.getMessage());
		} finally {
			if (entityManager != null) {
				//logger.info("entity manager is closeds");
				entityManager.close();
			}
		}
		if (user != null && userDetails.getPassword().equals(user.getPassword()))
			return user;
		else {
			//logger.info("Username or password does not match");
			throw new UASException("Username or password does not match");
		}
	}

}
