package com.capgemini.uas.service;

import java.sql.Date;
import java.util.List;

import com.capgemini.uas.bean.ApplicantBean;
import com.capgemini.uas.bean.ProgramOfferedBean;
import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.exception.UASException;

public interface IAdminService {

	List<ProgramOfferedBean> getAllProgramOffered();

	List<ProgramScheduledBean> getAllProgramScheduled() ;

	ProgramOfferedBean deleteProgOffered(String name);

	String addProgOffered(ProgramOfferedBean program);

	ProgramOfferedBean getProgOffered(String name);

	void updateProgOffered(ProgramOfferedBean program);

	String addProgScheduled(ProgramScheduledBean program);

	void deleteProgScheduled(String progId);

	List<ProgramScheduledBean> getDatedProgramScheduled(Date fromDate,
			Date toDate);
	
	List<ApplicantBean> getAllApplicantsApplied(String scheduleProgId) throws UASException;
	
	List<ApplicantBean> getAllApplicantsAccepted(String scheduleProgId) throws UASException;
	
	List<ApplicantBean> getAllApplicantsRejected(String scheduleProgId) throws UASException;
	
	List<ApplicantBean> getAllApplicantsConfirmed(String scheduleProgId) throws UASException;
	
	List<String> getProgramNameList();
	
	List<String> getProgramIdList();
}
