package com.capgemini.uas.service;

import com.capgemini.uas.bean.UsersBean;
import com.capgemini.uas.exception.UASException;

public interface IMainService {

	UsersBean isValidUserLogin(UsersBean user) throws UASException;

}
