package com.capgemini.uas.service;

import java.sql.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.uas.bean.ApplicantBean;
import com.capgemini.uas.bean.ProgramOfferedBean;
import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.dao.IAdminDao;
import com.capgemini.uas.exception.UASException;

@Transactional
@Service("adminService")
public class AdminServiceImpl implements IAdminService {

	@Autowired
	private IAdminDao adminDao;
	
	@Override
	public List<ProgramOfferedBean> getAllProgramOffered() {
		
		return adminDao.getAllProgramOffered();
	}

	@Override
	public ProgramOfferedBean deleteProgOffered(String name) {

		return adminDao.deleteProgOffered(name);
	}

	@Override
	public String addProgOffered(ProgramOfferedBean program) {

		return adminDao.addProgOffered(program);
	}

	@Override
	public ProgramOfferedBean getProgOffered(String name) {
		
		return adminDao.getProgOffered(name);
	}

	@Override
	public void updateProgOffered(ProgramOfferedBean program) {
		
		adminDao.updateProgOffered(program);
	}

	@Override
	public List<ProgramScheduledBean> getAllProgramScheduled() {
		
		return adminDao.getAllProgramScheduled();
	}

	@Override
	public String addProgScheduled(ProgramScheduledBean program) {
		
		return adminDao.addProgScheduled(program);
	}

	@Override
	public void deleteProgScheduled(String progId) {
		
		adminDao.deleteProgScheduled(progId);
	}

	@Override
	public List<ProgramScheduledBean> getDatedProgramScheduled(Date fromDate,
			Date toDate) {
		
		return adminDao.getDatedProgramScheduled(fromDate,toDate);
	}
	
	@Override
	public List<ApplicantBean> getAllApplicantsApplied(String scheduleProgId) throws UASException {
		return adminDao.getAllApplicantsApplied(scheduleProgId);
	}

	@Override
	public List<ApplicantBean> getAllApplicantsAccepted(String scheduleProgId) throws UASException {
		return adminDao.getAllApplicantsAccepted(scheduleProgId);
	}

	@Override
	public List<ApplicantBean> getAllApplicantsRejected(String scheduleProgId) throws UASException {
		return adminDao.getAllApplicantsRejected(scheduleProgId);
	}

	@Override
	public List<ApplicantBean> getAllApplicantsConfirmed(String scheduleProgId) throws UASException {
		return adminDao.getAllApplicantsConfirmed(scheduleProgId);
	}

	@Override
	public List<String> getProgramNameList() {

		return adminDao.getProgramNameList();
	}

	@Override
	public List<String> getProgramIdList() {
		
		return adminDao.getProgramIdList();
	}

}
