package com.capgemini.uas.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.uas.bean.UsersBean;
import com.capgemini.uas.dao.IMainDao;
import com.capgemini.uas.exception.UASException;

@Service("mainService")
public class MainServiceImpl implements IMainService{

	@Autowired
	private IMainDao mainDao;

	@Override
	public UsersBean isValidUserLogin(UsersBean user) throws UASException {
		return mainDao.isValidUserLogin(user);
	}
	
}
