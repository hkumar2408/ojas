package com.capgemini.uas.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.uas.bean.ApplicantBean;
import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.dao.IApplicantDao;
import com.capgemini.uas.exception.UASException;

@Transactional
@Service
public class ApplicantServiceImpl implements IApplicantService{

	@Autowired
	private IApplicantDao applicantDao;
	
	@Override
	public List<ProgramScheduledBean> getAllPrograms() throws UASException {
		System.out.println("Service impl of get all programs called");
		return applicantDao.getAllPrograms();
	}

	/*@Override
	public String getStatusbyId(int appId) throws UASException {
		return applicantDao.getStatusbyId(appId);
	}*/

	@Override
	public boolean saveApplication(ApplicantBean applicant) throws UASException {
		return applicantDao.saveApplication(applicant);
	}

	@Override
	public ApplicantBean getApplicationById(int appId) throws UASException {
		return applicantDao.getApplicationById(appId);
	}
	
}




