package com.capgemini.uas.service;

import java.util.List;

import com.capgemini.uas.bean.ApplicantBean;
import com.capgemini.uas.bean.ProgramScheduledBean;
import com.capgemini.uas.bean.UsersBean;
import com.capgemini.uas.exception.UASException;


public interface IMacService {

	UsersBean isValidUserLogin(UsersBean user) throws UASException;

	List<ApplicantBean> getAcceptedApplicant();

	boolean confirmApplicant(int appId);

	boolean rejectApplicant(int appId);

	boolean addParticipant(int appId, String emailId, String scheduleProgId);

	List<ApplicantBean> getApplicantList(String id);

	List<ProgramScheduledBean> getProgramList();

	List<ApplicantBean> getAppliedApplicant(String id);

	ApplicantBean fetchApplicant(int id);

	boolean updateInterviewDate(ApplicantBean applicant);


}
