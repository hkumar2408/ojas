drop table programs_offered cascade constraints;
drop table programs_scheduled cascade constraints;
drop table application cascade constraints;
drop table users cascade constraints;
drop table participant cascade constraints;
drop sequence applicationId_seq;
drop sequence participant_id;
commit;
