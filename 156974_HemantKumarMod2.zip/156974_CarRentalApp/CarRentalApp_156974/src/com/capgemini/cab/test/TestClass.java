package com.capgemini.cab.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.*;

import java.sql.Date;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.cab.bean.CabRequest;
import com.capgemini.cab.dao.CabRequestDAO;

public class TestClass {
	public static CabRequestDAO cabDAO = new CabRequestDAO();
	CabRequest cabRequest = new CabRequest();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

	}

	@Test
	public void testAddDetails1() {

		cabRequest.setRequestId(1005);
		cabRequest.setCustomerName("Hemant");
		cabRequest.setPhoneNumber("9012625757");
		cabRequest.setDateOfRequest(new Date(1996, 8, 21));
		cabRequest.setRequestStatus("Accepted");
		cabRequest.setCabNumber("MH VS 2345");
		cabRequest.setAddressOfPickup("ITPL");
		cabRequest.setPincode("490006");
	}

	@Test
	public void testAddDetails4() {
		assertNotNull(cabDAO);
	}

	@Test
	public void testAddDetails3() {
		assertTrue(cabDAO != null);
	}

}
