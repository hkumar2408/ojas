package com.capgemini.cab.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.cab.bean.CabRequest;
import com.capgemini.cab.service.CabService;

public class Client {
	public static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {

		PropertyConfigurator.configure("resource//log4j.properties");
		CabService cabService = new CabService();

		// Showing the menu
		System.out.println("1) Raise Cab Request");
		System.out.println("2) Exit ");
		logger.info("Application started....");

		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();

		switch (choice) {
		// Raise request option will be raised
		case 1:
			System.out.println("Enter the name of the customer: ");
			String customerName = sc.next();

			System.out.println("Enter customer phone number: ");
			String phoneNumber = sc.next();

			System.out.println("Enter Pick up address: ");
			String addressOfPickup = sc.next();

			System.out.println("Enter Pin Code: ");
			String pincode = sc.next();

			CabRequest cr = new CabRequest();
			cr.setCustomerName(customerName);
			cr.setPhoneNumber(phoneNumber);
			cr.setAddressOfPickup(addressOfPickup);
			cr.setPincode(pincode);

			int n = cabService.addCabRequestDetails(cr); // This will call service class of Cab request
															
			cabService.isValidEnquiry(cr);

			// If the return value is not null, then required id will be generated and will be displayed
			if (n != 0) {
				System.out
						.println("Your Cab request has been succesfully registered, your request ID is: "
								+ n);
			}
			break;

		// Exit option will invoke showing the pre-defined message
		case 2:
			System.out.println("Thankyou for visiting us");
			System.exit(0);

		}

	}

}
