package com.capgemini.cab.bean;

import java.sql.Date;

public class CabRequest {
	
	private int requestId;
	private String customerName;
	private String phoneNumber;
	private Date dateOfRequest;
	private String requestStatus;
	private String cabNumber;
	private String addressOfPickup;
	private String pincode;
	
	
	public int getRequestId() {
		return requestId;
	}
	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Date getDateOfRequest() {
		return dateOfRequest;
	}
	public void setDateOfRequest(Date dateOfRequest) {
		this.dateOfRequest = dateOfRequest;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	
	public String getAddressOfPickup() {
		return addressOfPickup;
	}
	public void setAddressOfPickup(String addressOfPickup) {
		this.addressOfPickup = addressOfPickup;
	}
	public String getCabNumber() {
		return cabNumber;
	}
	public void setCabNumber(String cabNumber) {
		this.cabNumber = cabNumber;
	}
	
	@Override
	public String toString() {
		return "CabRequest [requestId=" + requestId + ", customerName="
				+ customerName + ", phoneNumber=" + phoneNumber
				+ ", dateOfRequest=" + dateOfRequest + ", requestStatus="
				+ requestStatus + ", pincode=" + pincode + "]";
	}

}
