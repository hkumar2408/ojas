package com.capgemini.cab.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.cab.bean.CabRequest;
import com.capgemini.cab.dao.CabRequestDAO;

public class CabService implements ICabService {
	
	CabRequestDAO cabDAO = new CabRequestDAO();
	
	@Override
	public int addCabRequestDetails(CabRequest cabRequest){
		
		if(cabRequest.getPincode().equals("400096")){
			cabRequest.setRequestStatus("Accepted");
			cabRequest.setCabNumber("MH VS 2345");
			return cabDAO.addCabRequestDetails(cabRequest);
		}
		
		else if(cabRequest.getPincode().equals("411026")){
			cabRequest.setRequestStatus("Accepted");
			cabRequest.setCabNumber("MH VH 34567");
			return cabDAO.addCabRequestDetails(cabRequest);
		}
		
		else if(cabRequest.getPincode().equals("411013")){
			cabRequest.setRequestStatus("Accepted");
			cabRequest.setCabNumber("MH AN 97886");
			return cabDAO.addCabRequestDetails(cabRequest);
		}
		
		else if(cabRequest.getPincode().equals("560066")){
			cabRequest.setRequestStatus("Accepted");
			cabRequest.setCabNumber("MH AS 875");
			return cabDAO.addCabRequestDetails(cabRequest);
		}
		
		else if(cabRequest.getPincode().equals("382009")){
			cabRequest.setRequestStatus("Accepted");
			cabRequest.setCabNumber("MH KN 9856");
			return cabDAO.addCabRequestDetails(cabRequest);
		}
		
		else if(cabRequest.getPincode().equals("400708")){
			cabRequest.setRequestStatus("Accepted");
			cabRequest.setCabNumber("MH TF 8956");
			return cabDAO.addCabRequestDetails(cabRequest);
		}
		
		else{
			cabRequest.setRequestStatus("Not Accepted");
			cabRequest.setCabNumber("NULL");
			return cabDAO.addCabRequestDetails(cabRequest);
		}
		
		
	}

	@Override
	public boolean isValidEnquiry(CabRequest cabRequest) {
		Boolean validate = false;
	
		if(!(validateCustomerName(cabRequest.getCustomerName()))) {
			System.err.println("\n ERROR: First Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		
		//Validating Phone Number
		else if(!(validatePhoneNumber(cabRequest.getPhoneNumber()))){
			System.err.println("\nERROR:  Phone Number Should be in 10 digit \n");
		}
		//Validating Location
		else if(!(validateAddressOfPickup(cabRequest.getAddressOfPickup()))){
			System.err.println("\nERROR:  Address Should Be In Alphabets and minimum 4 characters long ! \n" );
		}

		else
			validate = true;
			
			return validate;
	}
	
	private boolean validateContactNo(long contactNo) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean validatePhoneNumber(CharSequence l){
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(l);
		return phoneMatcher.matches();
	}
	
	public boolean validateCustomerName(String customerName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(customerName);
		return nameMatcher.matches();
	}

	public boolean validateAddressOfPickup(String addressOfPickup){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{1,}$");
		Matcher nameMatcher=namePattern.matcher(addressOfPickup);
		return nameMatcher.matches();
		
	}
	
	
}
