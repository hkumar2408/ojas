package com.capgemini.cab.service;

import com.capgemini.cab.bean.CabRequest;


public interface ICabService {
	
	int addCabRequestDetails(CabRequest cabRequest);
	public boolean isValidEnquiry(CabRequest cabRequest);

}
