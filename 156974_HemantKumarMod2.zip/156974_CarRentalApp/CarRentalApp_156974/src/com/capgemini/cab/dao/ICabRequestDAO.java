package com.capgemini.cab.dao;

import com.capgemini.cab.bean.CabRequest;

public interface ICabRequestDAO {
	int addCabRequestDetails(CabRequest cabRequest);
}
