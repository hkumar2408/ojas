package com.capgemini.cab.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.cab.bean.CabRequest;

public class CabRequestDAO implements ICabRequestDAO {
	public static Logger logger = Logger.getRootLogger();
	
	
	//------------------------ 1. Raise Cab Request --------------------------
		/*******************************************************************************************************
		 - Function Name	:	addCabRequestDetails(CabRequest cabRequest)
		 - Input Parameters	:	CabRequest cabRequest
		 - Return Type		:	int
		 - Author			:	Hemant Kumar
		 - Creation Date	:	29/08/2018
		 - Description		:	Adding Request Details
		 ********************************************************************************************************/
	@Override
	public int addCabRequestDetails(CabRequest cabRequest){
		Connection conn = DBUtil.getConnection();
		PreparedStatement pstmt=null;
		PreparedStatement pstmt1=null;
		ResultSet resultset = null;
		int n=0, eid=0;
		try {
		pstmt =	conn.prepareStatement(QueryMapper.INSERT_QUERY);
				
				pstmt.setString(1, cabRequest.getCustomerName());
				pstmt.setLong(2, Long.parseLong(cabRequest.getPhoneNumber()));
				pstmt.setString(3, cabRequest.getRequestStatus());
				pstmt.setString(4, cabRequest.getCabNumber());
				pstmt.setString(5, cabRequest.getAddressOfPickup());
				pstmt.setString(6, cabRequest.getPincode());

		n =	pstmt.executeUpdate();
		if(n==0)
		{
			logger.error("Insertion failed ");
			eid = 0;
		}
		else{
			
			pstmt1 =conn.prepareStatement(QueryMapper.CURRVAL);
		resultset = pstmt1.executeQuery();
		
		if(resultset.next())
		{
			eid = resultset.getInt(1);	
		}
			logger.info("Enquiry details added successfully:");
		}
		
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return eid;
		
	}

}
