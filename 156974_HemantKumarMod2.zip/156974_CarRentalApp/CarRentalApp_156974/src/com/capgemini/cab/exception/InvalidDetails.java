package com.capgemini.cab.exception;

public class InvalidDetails extends Exception {

}
